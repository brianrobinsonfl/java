package BrianRobinson

import myTools.*;

public class Basics {

	//***********************************************
	static void logitTest() {
		myTools.logit(33);
		myTools.logit(5.5f);

		myTools.logit('c');
		myTools.logit('\n');
		myTools.logit("string");
	}

	//***********************************************
	public static void main(String[] args) {
		String label = "main";

		myTools.logit(true);
		myTools.logit("JAVA/J2EE & SOA");
	
		Module1 m1 = new Module1();
		m1.

		myTools.logit(false);

	} // END

} // END

