import myTools.*;

public class Module1 {

	//------------------------------------------------------------
	Module1() {  // Constructor
		myTools.logit("Module1", "Constructor");
	} // END

	//***********************************************
	void runExersize() {
		String label = "runExersize";

		myTools.logit(true);
		myTools.logit(label, "Module 1 Begin");
		
		// --------- If string contains Good
		ifStatementExample("Good");
		ifStatementExample("Bad");
		
		// ------- forLoopExample --- print contents of objet -----
		Object[] o = new Object[10];
		o[0]="test forLoop";
		o[1]=1234;
		o[2]=12.34F;
		forLoopExample(o);

		// ------- whileExample --- print contents of objet -----
		o[0]="test whileLoop";
		o[1]=5678;
		o[2]=56.78F;
		whileExample(o);

		// ------- doWhileExample --- print contents of objet -----
		o[0]="test doWhileLoop";
		o[1]=9012;
		o[2]=90.12F;
		doWhileExample(o);

		myTools.logit(false);

	} // END

	//------------------------------------------------------------
	void ifStatementExample(String txt) {  // ifStatement
		String label = "ifStatementExample";
		myTools.logit();
		//myTools.logit(label,txt);
		if(txt.toUpperCase().contains("GOOD") == true) {
			myTools.logit(label,"Good");
		} else {
			myTools.logit(label,"Bad");
		}
		//myTools.logit(false);
		return;
	} // END

	//------------------------------------------------------------
	void forLoopExample(Object o[]) {
		String label = "forLoopExample";
		myTools.logit();
		//myTools.logit(label,o.length,o.toString());
		for (int i = 0; i < o.length && o[i] != null; i++) { // increment I after For process Block
			myTools.logit(label,o[i]);
		}
		return;
	} // END

	//------------------------------------------------------------
	void whileExample(Object o[]) {
		String label = "whileExample";
		myTools.logit();
		//myTools.logit(label,o.length,o.toString());
		int i = 0;
		while(i < o.length && o[i] != null) {
			myTools.logit(label,o[i++]);  // increment I after While, in process Block
		} 

		return;
	} // END

	//------------------------------------------------------------
	void doWhileExample(Object o[]) {
		String label = "doWhileExample";
		myTools.logit();
		//myTools.logit(label,o.length,o.toString());
		int i = 0;
		do {
			myTools.logit(label,o[i]);
		}
		while(i < o.length && o[++i] != null); 		// increment I BEFORE !!! While Condition, after process Block

		return;
	} // END
	
} // END

